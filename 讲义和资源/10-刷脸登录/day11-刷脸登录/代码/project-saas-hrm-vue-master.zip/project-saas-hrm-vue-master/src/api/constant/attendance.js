// 员工端
export default {
  // 假期类型
  holidayType: [
    {
      id: '1',
      value: '正常'
    },
    {
      id: '2',
      value: '旷工'
    },
    {
      id: '3',
      value: '事假'
    },
    {
      id: '4',
      value: '调休'
    },
    {
      id: '5',
      value: '迟到'
    },
    {
      id: '6',
      value: '早退'
    }
  ]
}
