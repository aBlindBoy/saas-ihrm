// 招聘
export default {
  // 招聘任务类型
  recruitTaskType: [
    {
      id: '1',
      value: '推荐'
    },
    {
      id: '2',
      value: '面试'
    }
  ]
}
