module.exports = file => () => import('@/module-' + file + '.vue')
